import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

class AppState extends ChangeNotifier {
  String lang = 'ar';
  String? countryId;

  Country? get country {
    for (final c in countries) {
      if (c.id == countryId) return c;
    }
    return null;
  }

  bool get rtl => lang == 'ar';

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    lang = p.getString('lang') ?? 'ar';
    countryId = p.getString('country');
  }

  Future<void> setLang(String v) async {
    lang = v;
    notifyListeners();
    final p = await SharedPreferences.getInstance();
    await p.setString('lang', v);
  }

  Future<void> setCountry(String v) async {
    countryId = v;
    notifyListeners();
    final p = await SharedPreferences.getInstance();
    await p.setString('country', v);
  }

  Future<void> reset() async {
    countryId = null;
    notifyListeners();
    final p = await SharedPreferences.getInstance();
    await p.remove('country');
  }
}
