class Config {
  /// رابط مجلد data في مستودع GitHub الذي يحدّثه الخادم كل 12 ساعة.
  /// غيّر YOUR_GITHUB_USER إلى اسم حسابك، واسم المستودع إن اختلف.
  static const String dataBaseUrl =
      'https://raw.githubusercontent.com/YOUR_GITHUB_USER/mujaz/main/data';

  /// المدة التي نعتبر فيها الأخبار المخزنة على الجهاز حديثة.
  static const Duration refreshEvery = Duration(hours: 12);
}
