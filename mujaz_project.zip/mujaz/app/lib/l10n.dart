const Map<String, Map<String, String>> _t = {
  'ar': {
    'appName': 'موجز',
    'lead': 'أخبار بلدك في دقيقتين، تقرأها أو تسمعها.',
    'language': 'اللغة',
    'pickCountry': 'اختر الدولة',
    'start': 'ابدأ',
    'change': 'تغيير',
    'hello': 'أهم ما يهمك اليوم',
    'stories': 'أخبار',
    'listenAll': 'اسمع ملخص القسم',
    'listen': 'اسمع الخبر',
    'stop': 'إيقاف',
    'speed': 'السرعة',
    'source': 'المصدر',
    'readFull': 'قراءة الخبر كاملًا في المصدر',
    'updated': 'آخر تحديث',
    'offline': 'تعرض أخبارًا محفوظة على جهازك.',
    'empty': 'لا توجد أخبار حاليًا. تحقق من الاتصال ثم اسحب للتحديث.',
    'retry': 'إعادة المحاولة',
    'sec_general': 'أهم الأخبار',
    'sec_economy': 'الاقتصاد',
    'sec_sports': 'الرياضة',
    'sec_tech': 'التقنية',
    'sec_health': 'الصحة',
    'sec_culture': 'الثقافة',
  },
  'en': {
    'appName': 'Mujaz',
    'lead': "Your country's news in two minutes. Read it or listen.",
    'language': 'Language',
    'pickCountry': 'Choose a country',
    'start': 'Start',
    'change': 'Change',
    'hello': 'What matters today',
    'stories': 'stories',
    'listenAll': 'Listen to section brief',
    'listen': 'Listen to story',
    'stop': 'Stop',
    'speed': 'Speed',
    'source': 'Source',
    'readFull': 'Read the full story at the source',
    'updated': 'Last updated',
    'offline': 'Showing news saved on your device.',
    'empty': 'No news right now. Check your connection and pull to refresh.',
    'retry': 'Try again',
    'sec_general': 'Top stories',
    'sec_economy': 'Economy',
    'sec_sports': 'Sports',
    'sec_tech': 'Technology',
    'sec_health': 'Health',
    'sec_culture': 'Culture',
  },
};

String tr(String lang, String key) => _t[lang]?[key] ?? key;

const _monthsAr = [
  'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
  'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
];
const _monthsEn = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
];

String formatDate(DateTime? d, String lang) {
  if (d == null) return '';
  final l = d.toLocal();
  final m = (lang == 'ar' ? _monthsAr : _monthsEn)[l.month - 1];
  return '${l.day} $m';
}

String formatDateTime(DateTime? d, String lang) {
  if (d == null) return '';
  final l = d.toLocal();
  final hh = l.hour.toString().padLeft(2, '0');
  final mm = l.minute.toString().padLeft(2, '0');
  return '${formatDate(d, lang)} $hh:$mm';
}
