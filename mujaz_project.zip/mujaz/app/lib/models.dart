class Story {
  final String id;
  final String section;
  final String title;
  final String summary;
  final String source;
  final String url;
  final DateTime? publishedAt;

  const Story({
    required this.id,
    required this.section,
    required this.title,
    required this.summary,
    required this.source,
    required this.url,
    this.publishedAt,
  });

  /// مفتاح فريد للقراءة الصوتية (قد يتكرر الخبر نفسه في قسمين).
  String get key => '$section:$id';

  factory Story.fromJson(Map<String, dynamic> j) => Story(
        id: (j['id'] ?? '').toString(),
        section: (j['section'] ?? 'general').toString(),
        title: (j['title'] ?? '').toString(),
        summary: (j['summary'] ?? '').toString(),
        source: (j['source'] ?? '').toString(),
        url: (j['url'] ?? '').toString(),
        publishedAt: j['publishedAt'] == null
            ? null
            : DateTime.tryParse(j['publishedAt'].toString()),
      );
}

class Country {
  final String id;
  final String flag;
  final String ar;
  final String en;
  const Country(this.id, this.flag, this.ar, this.en);

  String name(String lang) => lang == 'ar' ? ar : en;
}

/// الدول المتاحة. أضف دولة هنا وأضف مصادرها في server/sources.json.
const List<Country> countries = [
  Country('om', '🇴🇲', 'عُمان', 'Oman'),
];

const List<String> sections = [
  'general',
  'economy',
  'sports',
  'tech',
  'health',
  'culture',
];
