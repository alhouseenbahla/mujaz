import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'config.dart';
import 'models.dart';

class NewsResult {
  final List<Story> stories;
  final DateTime? updatedAt;
  final bool fromCache;
  const NewsResult(this.stories, this.updatedAt, this.fromCache);
}

/// يجلب ملف JSON الذي يحدّثه الخادم كل 12 ساعة، ويحفظ نسخة على الجهاز
/// حتى يعمل التطبيق بدون إنترنت.
class NewsRepository {
  Future<NewsResult> load(String country, String lang,
      {bool force = false}) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'news_${country}_$lang';
    final tsKey = '${key}_fetched';
    final cached = prefs.getString(key);
    final fetchedMs = prefs.getInt(tsKey);

    final fresh = fetchedMs != null &&
        DateTime.now()
                .difference(DateTime.fromMillisecondsSinceEpoch(fetchedMs)) <
            Config.refreshEvery;

    if (cached != null && fresh && !force) {
      final r = _parse(cached, true);
      if (r != null) return r;
    }

    try {
      final uri = Uri.parse('${Config.dataBaseUrl}/news_${country}_$lang.json');
      final res = await http.get(uri).timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final body = utf8.decode(res.bodyBytes);
        final parsed = _parse(body, false);
        if (parsed != null) {
          await prefs.setString(key, body);
          await prefs.setInt(tsKey, DateTime.now().millisecondsSinceEpoch);
          return parsed;
        }
      }
    } catch (_) {
      // لا اتصال أو خطأ في الخادم: نرجع إلى النسخة المحفوظة.
    }

    if (cached != null) {
      final r = _parse(cached, true);
      if (r != null) return r;
    }
    return const NewsResult([], null, true);
  }

  NewsResult? _parse(String body, bool fromCache) {
    try {
      final j = jsonDecode(body) as Map<String, dynamic>;
      final list = (j['stories'] as List? ?? [])
          .map((e) => Story.fromJson(e as Map<String, dynamic>))
          .where((s) => s.title.isNotEmpty)
          .toList();
      final updated = j['updatedAt'] == null
          ? null
          : DateTime.tryParse(j['updatedAt'].toString());
      return NewsResult(list, updated, fromCache);
    } catch (_) {
      return null;
    }
  }
}
