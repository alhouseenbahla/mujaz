import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_state.dart';
import '../l10n.dart';
import '../models.dart';
import '../news_repository.dart';
import '../widgets.dart';
import 'section_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _repo = NewsRepository();
  String _key = '';
  Future<NewsResult>? _future;

  void _ensure(AppState s, {bool force = false}) {
    final k = '${s.countryId}_${s.lang}';
    if (k != _key || force || _future == null) {
      _key = k;
      _future = _repo.load(s.countryId!, s.lang, force: force);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final c = s.country;
    if (c == null) return const SizedBox.shrink();
    _ensure(s);
    final lang = s.lang;

    return Scaffold(
      appBar: AppBar(
        title: Text('${c.flag}  ${c.name(lang)}'),
        actions: [
          TextButton(onPressed: s.reset, child: Text(tr(lang, 'change'))),
        ],
      ),
      body: FutureBuilder<NewsResult>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          final data = snap.data ?? const NewsResult([], null, true);
          if (data.stories.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(tr(lang, 'empty'), textAlign: TextAlign.center),
                    const SizedBox(height: 12),
                    OutlinedButton(
                      onPressed: () => setState(() => _ensure(s, force: true)),
                      child: Text(tr(lang, 'retry')),
                    ),
                  ],
                ),
              ),
            );
          }

          final bySection = <String, List<Story>>{};
          for (final sec in sections) {
            final list = data.stories.where((e) => e.section == sec).toList();
            if (list.isNotEmpty) bySection[sec] = list;
          }
          final keys = bySection.keys.toList();

          return RefreshIndicator(
            onRefresh: () async {
              setState(() => _ensure(s, force: true));
              await _future;
            },
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
              children: [
                Text(tr(lang, 'hello'),
                    style: const TextStyle(
                        fontSize: 24, fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text(
                  '${tr(lang, 'updated')}: ${formatDateTime(data.updatedAt, lang)}'
                  '${data.fromCache ? '  ·  ${tr(lang, 'offline')}' : ''}',
                  style: TextStyle(
                      fontSize: 12,
                      color: Theme.of(context).colorScheme.onSurfaceVariant),
                ),
                const SizedBox(height: 14),
                LayoutBuilder(builder: (context, cons) {
                  final half = (cons.maxWidth - 10) / 2;
                  return Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      for (var i = 0; i < keys.length; i++)
                        SizedBox(
                          width: i == 0 ? cons.maxWidth : half,
                          child: _SectionTile(
                            section: keys[i],
                            stories: bySection[keys[i]]!,
                            wide: i == 0,
                            lang: lang,
                          ),
                        ),
                    ],
                  );
                }),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _SectionTile extends StatelessWidget {
  final String section;
  final List<Story> stories;
  final bool wide;
  final String lang;

  const _SectionTile({
    required this.section,
    required this.stories,
    required this.wide,
    required this.lang,
  });

  @override
  Widget build(BuildContext context) {
    final muted = Theme.of(context).colorScheme.onSurfaceVariant;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => SectionScreen(section: section, stories: stories),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            SectionArt(
              section: section,
              height: wide ? 120 : 84,
              iconSize: wide ? 48 : 36,
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(tr(lang, 'sec_$section'),
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  Text(
                    stories.first.title,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 14, color: muted),
                  ),
                  const SizedBox(height: 8),
                  Text('${stories.length} ${tr(lang, 'stories')}',
                      style: TextStyle(fontSize: 12, color: muted)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
