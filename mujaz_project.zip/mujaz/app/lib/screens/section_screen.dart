import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_state.dart';
import '../l10n.dart';
import '../models.dart';
import '../tts_service.dart';
import '../widgets.dart';
import 'story_screen.dart';

class SectionScreen extends StatefulWidget {
  final String section;
  final List<Story> stories;
  const SectionScreen({super.key, required this.section, required this.stories});

  @override
  State<SectionScreen> createState() => _SectionScreenState();
}

class _SectionScreenState extends State<SectionScreen> {
  late TtsService _tts;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _tts = context.read<TtsService>();
  }

  @override
  void dispose() {
    _tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final lang = context.watch<AppState>().lang;
    final muted = Theme.of(context).colorScheme.onSurfaceVariant;
    final all = widget.stories.map((e) => '${e.title}. ${e.summary}').join(' ... ');

    return Scaffold(
      appBar: AppBar(title: Text(tr(lang, 'sec_${widget.section}'))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
        children: [
          BigListen(
            keyId: 'all:${widget.section}',
            text: all,
            label: tr(lang, 'listenAll'),
          ),
          const SizedBox(height: 14),
          for (final st in widget.stories) ...[
            Card(
              clipBehavior: Clip.antiAlias,
              child: InkWell(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => StoryScreen(story: st)),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: SectionArt(
                          section: widget.section,
                          width: 88,
                          height: 88,
                          iconSize: 34,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(st.title,
                                maxLines: 4,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    fontSize: 15, fontWeight: FontWeight.w600)),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    [st.source, formatDate(st.publishedAt, lang)]
                                        .where((e) => e.isNotEmpty)
                                        .join(' · '),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(fontSize: 12, color: muted),
                                  ),
                                ),
                                MiniListen(
                                  keyId: st.key,
                                  text: '${st.title}. ${st.summary}',
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),
          ],
        ],
      ),
    );
  }
}
