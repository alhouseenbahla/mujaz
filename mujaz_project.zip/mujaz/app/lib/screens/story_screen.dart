import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../app_state.dart';
import '../l10n.dart';
import '../models.dart';
import '../theme.dart';
import '../tts_service.dart';
import '../widgets.dart';

class StoryScreen extends StatefulWidget {
  final Story story;
  const StoryScreen({super.key, required this.story});

  @override
  State<StoryScreen> createState() => _StoryScreenState();
}

class _StoryScreenState extends State<StoryScreen> {
  late TtsService _tts;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _tts = context.read<TtsService>();
  }

  @override
  void dispose() {
    _tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final lang = context.watch<AppState>().lang;
    final st = widget.story;
    final muted = Theme.of(context).colorScheme.onSurfaceVariant;
    final meta = [
      tr(lang, 'sec_${st.section}'),
      formatDate(st.publishedAt, lang),
      if (st.source.isNotEmpty) '${tr(lang, 'source')}: ${st.source}',
    ].where((e) => e.isNotEmpty).join(' · ');

    return Scaffold(
      appBar: AppBar(),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 32),
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: SectionArt(section: st.section, height: 170, iconSize: 64),
          ),
          const SizedBox(height: 14),
          Text(st.title,
              style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Text(meta, style: TextStyle(fontSize: 12, color: muted)),
          const SizedBox(height: 18),
          BigListen(
            keyId: st.key,
            text: '${st.title}. ${st.summary}',
            label: tr(lang, 'listen'),
          ),
          const SizedBox(height: 10),
          Consumer<TtsService>(builder: (context, tts, _) {
            return Row(
              children: [
                Text(tr(lang, 'speed'), style: TextStyle(color: muted)),
                const SizedBox(width: 8),
                for (final v in const [1.0, 1.25, 1.5]) ...[
                  ChoiceChip(
                    label: Text('${v}x'),
                    selected: tts.speed == v,
                    onSelected: (_) {
                      tts.setSpeed(v);
                      if (tts.currentId == st.key) {
                        tts.speak(st.key, '${st.title}. ${st.summary}', lang);
                      }
                    },
                  ),
                  const SizedBox(width: 6),
                ],
              ],
            );
          }),
          const SizedBox(height: 16),
          Text(st.summary, style: const TextStyle(fontSize: 17, height: 1.9)),
          if (st.url.isNotEmpty) ...[
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                style: OutlinedButton.styleFrom(
                  foregroundColor: kBrand,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                onPressed: () => launchUrl(Uri.parse(st.url),
                    mode: LaunchMode.externalApplication),
                child: Text(tr(lang, 'readFull')),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
