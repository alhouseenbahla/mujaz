import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_state.dart';
import '../l10n.dart';
import '../models.dart';
import '../theme.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  String? _pick;

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final lang = s.lang;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 28, 20, 24),
              children: [
                Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: Container(
                    width: 72,
                    height: 72,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      gradient: const LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Color(0xFF0A6B6B), Color(0xFF14A39A)],
                      ),
                    ),
                    child: const Icon(Icons.newspaper,
                        color: Colors.white, size: 38),
                  ),
                ),
                const SizedBox(height: 12),
                Text(tr(lang, 'appName'),
                    style: const TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.w700,
                        color: kBrand)),
                const SizedBox(height: 2),
                Text(tr(lang, 'lead')),
                const SizedBox(height: 24),
                Text(tr(lang, 'language'),
                    style: const TextStyle(fontWeight: FontWeight.w500)),
                const SizedBox(height: 8),
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: 'ar', label: Text('العربية')),
                    ButtonSegment(value: 'en', label: Text('English')),
                  ],
                  selected: {lang},
                  onSelectionChanged: (v) => s.setLang(v.first),
                ),
                const SizedBox(height: 24),
                Text(tr(lang, 'pickCountry'),
                    style: const TextStyle(fontWeight: FontWeight.w500)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final c in countries)
                      ChoiceChip(
                        selected: _pick == c.id,
                        label: Text('${c.flag}  ${c.name(lang)}',
                            style: const TextStyle(fontSize: 16)),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 10),
                        onSelected: (_) => setState(() => _pick = c.id),
                      ),
                  ],
                ),
                const SizedBox(height: 28),
                FilledButton(
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    textStyle: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.w600),
                  ),
                  onPressed: _pick == null ? null : () => s.setCountry(_pick!),
                  child: Text(tr(lang, 'start')),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
