import 'package:flutter/material.dart';

const Color kBrand = Color(0xFF0A6B6B);
const Color kListen = Color(0xFFC93F0C);

ThemeData buildTheme(Brightness b) {
  final dark = b == Brightness.dark;
  final scheme = ColorScheme.fromSeed(seedColor: kBrand, brightness: b);
  final bg = dark ? const Color(0xFF0C1A1E) : const Color(0xFFEEF2F3);
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: bg,
    appBarTheme: AppBarTheme(
      backgroundColor: bg,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
    ),
    cardTheme: CardThemeData(
      color: dark ? const Color(0xFF142428) : Colors.white,
      elevation: 0,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(
            color: dark ? const Color(0xFF24383D) : const Color(0xFFD5DEE0)),
      ),
    ),
  );
}
