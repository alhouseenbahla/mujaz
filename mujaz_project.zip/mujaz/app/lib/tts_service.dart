import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';

/// القراءة الصوتية. تستخدم صوت النظام (Android وiOS). لصوت أجود لاحقًا
/// يمكن استبدال هذا الصنف بخدمة صوت عصبي سحابية تشغّل ملفات MP3.
class TtsService extends ChangeNotifier {
  final FlutterTts _tts = FlutterTts();

  /// مفتاح الخبر الذي يُقرأ الآن، أو null.
  String? currentId;
  double speed = 1.0;

  TtsService() {
    _init();
  }

  Future<void> _init() async {
    try {
      await _tts.setSharedInstance(true);
    } catch (_) {}
    _tts.setCompletionHandler(_done);
    _tts.setErrorHandler((msg) {
      if (!msg.toString().toLowerCase().contains('interrupt')) _done();
    });
  }

  void _done() {
    if (currentId != null) {
      currentId = null;
      notifyListeners();
    }
  }

  Future<void> speak(String id, String text, String lang) async {
    await _tts.stop();
    await _tts.setLanguage(lang == 'ar' ? 'ar-SA' : 'en-US');
    await _tts.setSpeechRate((0.5 * speed).clamp(0.1, 1.0));
    await _tts.setVolume(1.0);
    currentId = id;
    notifyListeners();
    await _tts.speak(text);
  }

  Future<void> stop() async {
    await _tts.stop();
    if (currentId != null) {
      currentId = null;
      notifyListeners();
    }
  }

  void setSpeed(double v) {
    speed = v;
    notifyListeners();
  }
}
