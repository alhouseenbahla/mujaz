import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'app_state.dart';
import 'l10n.dart';
import 'theme.dart';
import 'tts_service.dart';

/// رسمة القسم: تدرج لوني مع أيقونة. تُستبدل بصورة الخبر لاحقًا
/// عند الحصول على ترخيص للصور.
class SectionArt extends StatelessWidget {
  final String section;
  final double? width;
  final double height;
  final double iconSize;

  const SectionArt({
    super.key,
    required this.section,
    this.width,
    this.height = 84,
    this.iconSize = 36,
  });

  static const Map<String, List<Color>> _gradients = {
    'general': [Color(0xFF0A6B6B), Color(0xFF14A39A)],
    'economy': [Color(0xFF1E6B3A), Color(0xFF3AA65C)],
    'sports': [Color(0xFFC93F0C), Color(0xFFF08A3C)],
    'tech': [Color(0xFF1B3A4B), Color(0xFF2E7F9E)],
    'health': [Color(0xFFA82248), Color(0xFFE0587A)],
    'culture': [Color(0xFF7A4A1E), Color(0xFFD39A45)],
  };

  static const Map<String, IconData> _icons = {
    'general': Icons.public,
    'economy': Icons.trending_up,
    'sports': Icons.sports_soccer,
    'tech': Icons.memory,
    'health': Icons.favorite,
    'culture': Icons.account_balance,
  };

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width ?? double.infinity,
      height: height,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: _gradients[section] ?? _gradients['general']!,
        ),
      ),
      child: Center(
        child: Icon(
          _icons[section] ?? Icons.public,
          size: iconSize,
          color: const Color.fromRGBO(255, 255, 255, 0.92),
        ),
      ),
    );
  }
}

/// زر تشغيل دائري صغير على بطاقة الخبر.
class MiniListen extends StatelessWidget {
  final String keyId;
  final String text;
  const MiniListen({super.key, required this.keyId, required this.text});

  @override
  Widget build(BuildContext context) {
    final lang = context.read<AppState>().lang;
    return Consumer<TtsService>(builder: (context, tts, _) {
      final on = tts.currentId == keyId;
      return IconButton.filled(
        style: IconButton.styleFrom(
          backgroundColor: kListen,
          foregroundColor: Colors.white,
        ),
        tooltip: tr(lang, on ? 'stop' : 'listen'),
        icon: Icon(on ? Icons.stop : Icons.play_arrow),
        onPressed: () => on ? tts.stop() : tts.speak(keyId, text, lang),
      );
    });
  }
}

/// زر تشغيل كبير (ملخص القسم أو الخبر).
class BigListen extends StatelessWidget {
  final String keyId;
  final String text;
  final String label;
  const BigListen(
      {super.key,
      required this.keyId,
      required this.text,
      required this.label});

  @override
  Widget build(BuildContext context) {
    final lang = context.read<AppState>().lang;
    return Consumer<TtsService>(builder: (context, tts, _) {
      final on = tts.currentId == keyId;
      return SizedBox(
        width: double.infinity,
        child: FilledButton.icon(
          style: FilledButton.styleFrom(
            backgroundColor: kListen,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 16),
            textStyle:
                const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
          icon: Icon(on ? Icons.stop : Icons.play_arrow),
          label: Text(on ? tr(lang, 'stop') : label),
          onPressed: () => on ? tts.stop() : tts.speak(keyId, text, lang),
        ),
      );
    });
  }
}
