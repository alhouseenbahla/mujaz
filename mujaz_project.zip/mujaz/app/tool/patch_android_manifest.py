#!/usr/bin/env python3
"""يعدّل AndroidManifest.xml بعد flutter create:
 - إذن الإنترنت (مطلوب في نسخة الإصدار)
 - السماح بالوصول لخدمة القراءة الصوتية وفتح الروابط (أندرويد 11 فأحدث)
 - اسم التطبيق «موجز»
شغّله من مجلد app مرة واحدة.
"""
from pathlib import Path

p = Path("android/app/src/main/AndroidManifest.xml")
if not p.exists():
    raise SystemExit("شغّل flutter create أولًا ثم نفّذ هذا السكربت من مجلد app")

s = p.read_text(encoding="utf-8")

if "android.permission.INTERNET" not in s:
    s = s.replace("<application", '<uses-permission android:name="android.permission.INTERNET"/>\n    <application', 1)

if "android.intent.action.TTS_SERVICE" not in s:
    queries = """<queries>
        <intent><action android:name="android.intent.action.TTS_SERVICE"/></intent>
        <intent>
            <action android:name="android.intent.action.VIEW"/>
            <data android:scheme="https"/>
        </intent>
    </queries>
    <application"""
    s = s.replace("<application", queries, 1)

s = s.replace('android:label="mujaz"', 'android:label="موجز"')
p.write_text(s, encoding="utf-8")
print("تم تعديل AndroidManifest.xml")
