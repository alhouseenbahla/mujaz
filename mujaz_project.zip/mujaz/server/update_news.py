#!/usr/bin/env python3
"""يجلب الأخبار من خلاصات RSS ويلخّصها بالعربية والإنجليزية ثم يكتب ملفات JSON
في مجلد data/ ليقرأها التطبيق. يعمل كل 12 ساعة عبر GitHub Actions.

المتطلبات: متغير البيئة ANTHROPIC_API_KEY.
"""
import hashlib
import json
import os
import re
import sys
import time
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path

import anthropic

try:
    import trafilatura
except ImportError:  # يعمل بدونها لكن بنص أقل
    trafilatura = None

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
SOURCES = Path(__file__).resolve().parent / "sources.json"

MODEL = os.environ.get("MUJAZ_MODEL", "claude-haiku-5-5")
FETCH_PER_SECTION = int(os.environ.get("MUJAZ_FETCH_PER_SECTION", "4"))
OUT_PER_SECTION = int(os.environ.get("MUJAZ_OUT_PER_SECTION", "6"))
KEEP_DAYS = 7
UA = "Mozilla/5.0 (compatible; MujazBot/1.0)"

PROMPT = """You write short news briefs for a mobile news app.
Use ONLY facts stated in the article text below. Do not add facts, do not guess,
and do not copy sentences: rewrite everything in your own words.

Return JSON only, with this exact shape:
{"skip": false,
 "en": {"title": "...", "summary": "..."},
 "ar": {"title": "...", "summary": "..."}}

Rules:
- title: neutral, at most 90 characters.
- summary: exactly 2 short sentences, at most 320 characters.
- Arabic: clear Modern Standard Arabic in a natural news style, Western digits.
- If the text does not contain enough information for a faithful summary,
  return {"skip": true}.

Article title: __TITLE__

Article text:
__TEXT__
"""


def http_get(url: str, timeout: int = 20) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def parse_feed(url: str):
    root = ET.fromstring(http_get(url))
    items = []
    for it in root.iter("item"):
        title = (it.findtext("title") or "").strip()
        link = (it.findtext("link") or "").strip()
        desc = re.sub(r"<[^>]+>", "", it.findtext("description") or "").strip()
        dt = None
        try:
            dt = parsedate_to_datetime(it.findtext("pubDate") or "").astimezone(timezone.utc)
        except Exception:
            pass
        if title and link:
            items.append({"title": title, "url": link, "desc": desc, "date": dt})
    items.sort(key=lambda x: x["date"] or datetime(1970, 1, 1, tzinfo=timezone.utc), reverse=True)
    return items


def article_text(url: str, fallback: str) -> str:
    if trafilatura:
        try:
            html = http_get(url).decode("utf-8", "ignore")
            text = trafilatura.extract(html) or ""
            if len(text) > 300:
                return text[:6000]
        except Exception:
            pass
    return fallback


def summarize(client, title: str, text: str):
    prompt = PROMPT.replace("__TITLE__", title).replace("__TEXT__", text)
    msg = client.messages.create(
        model=MODEL,
        max_tokens=900,
        messages=[{"role": "user", "content": prompt}],
    )
    raw = msg.content[0].text
    a, b = raw.find("{"), raw.rfind("}")
    if a < 0 or b < 0:
        return None
    data = json.loads(raw[a : b + 1])
    if data.get("skip"):
        return None
    for lang in ("ar", "en"):
        if not data.get(lang, {}).get("title") or not data.get(lang, {}).get("summary"):
            return None
    return data


def load_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def main() -> int:
    if not os.environ.get("ANTHROPIC_API_KEY"):
        print("ANTHROPIC_API_KEY is not set", file=sys.stderr)
        return 1
    client = anthropic.Anthropic()
    cfg = load_json(SOURCES, {"countries": {}})
    DATA.mkdir(exist_ok=True)
    now = datetime.now(timezone.utc)
    cutoff = now - timedelta(days=KEEP_DAYS)

    for cid, c in cfg["countries"].items():
        cache_path = DATA / f"_cache_{cid}.json"
        cache = load_json(cache_path, {})  # id -> entry
        added = 0

        for section, feeds in c["feeds"].items():
            for feed in feeds:
                try:
                    items = parse_feed(feed)[:FETCH_PER_SECTION]
                except Exception as e:
                    print(f"[{cid}/{section}] feed failed: {feed} ({e})")
                    continue
                for it in items:
                    sid = hashlib.sha1(it["url"].encode()).hexdigest()[:12]
                    key = f"{section}:{sid}"
                    if key in cache:
                        continue
                    if it["date"] and it["date"] < cutoff:
                        continue
                    text = article_text(it["url"], it["desc"])
                    if len(text) < 80:
                        continue
                    try:
                        res = summarize(client, it["title"], text)
                    except Exception as e:
                        print(f"[{cid}/{section}] summarize failed: {e}")
                        continue
                    if not res:
                        continue
                    cache[key] = {
                        "id": sid,
                        "section": section,
                        "source": c.get("source", ""),
                        "url": it["url"],
                        "publishedAt": it["date"].isoformat() if it["date"] else None,
                        "addedAt": now.isoformat(),
                        "ar": res["ar"],
                        "en": res["en"],
                    }
                    added += 1
                    time.sleep(0.5)

        # حذف الأخبار القديمة
        def when(e):
            s = e.get("publishedAt") or e.get("addedAt")
            return datetime.fromisoformat(s)

        cache = {k: v for k, v in cache.items() if when(v) >= cutoff}
        cache_path.write_text(json.dumps(cache, ensure_ascii=False, indent=1), encoding="utf-8")

        # كتابة ملفات التطبيق
        for lang in ("ar", "en"):
            stories = []
            for section in c["feeds"].keys():
                entries = [e for e in cache.values() if e["section"] == section]
                entries.sort(key=when, reverse=True)
                for e in entries[:OUT_PER_SECTION]:
                    stories.append({
                        "id": e["id"],
                        "section": e["section"],
                        "title": e[lang]["title"],
                        "summary": e[lang]["summary"],
                        "source": e["source"],
                        "url": e["url"],
                        "publishedAt": e["publishedAt"],
                    })
            out = {"updatedAt": now.isoformat(), "stories": stories}
            (DATA / f"news_{cid}_{lang}.json").write_text(
                json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8"
            )
        print(f"[{cid}] added {added}, total {len(cache)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
